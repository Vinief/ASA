<?php

echo 'qualquer coisa';

?>
