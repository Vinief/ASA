<?php
Session_start();
if ((isset($_GET['senha_atual'])) and (isset($_GET['confirmar_senha'])) and (isset($_GET['nova_senha']))){
	$senha_nova	=$_GET['nova_senha'];
	$senha_antiga	=$_GET['senha_atual'];
	$senha_conf	=$_GET['confirmar_senha'];
	$email		=$_SESSION['email'];

}

else
	die('Erro na passagem de par&acirc;metros');

if ($senha_nova == $senha_conf){
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	$bd = new mysqli("192.168.102.100", "CONTAINER032", "1F(803292)", "BD032");
	if ($bd->connect_errno){
		die("Falha ao conectar ao MySQL: (" . $bd->connect_errno . ") " . $bd->connect_error);
	}

	$bd->query("UPDATE senha from banco_geral where email='$email' and senha='$senha_antiga'");
	if ($bd->errno){
		die("Erro na execucao do SQL: $sql ($bd->errno) $bd->error");
	};
	}

if ($_SESSION['ativo'] == 'm'){
	header("Location: http://" .$_SESSION['login']. "/mestre.php");
    
	}
if ($_SESSION['ativo'] == 's'){
	header("Location: http://" .$_SESSION['login']. "/dominios.php");
    
	}
if ($_SESSION['ativo'] == 'u'){
	header("Location: http://" .$_SESSION['login']. "/usarios.php");
    
	}
else{
	header("Location: index.php");
}
?>
